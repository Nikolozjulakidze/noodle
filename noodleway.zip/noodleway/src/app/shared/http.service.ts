import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  getProductBySlug(slug: string) {
    throw new Error('Method not implemented.');
  }

  private apiUrl = 'https://your-api-url/products'; // Replace with your actual API URL

  constructor(private http: HttpClient) { }

  getProductById(productId: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${productId}`).pipe(
      catchError(error => {
        console.error('Error fetching product', error);
        throw error; // Throw error for component to handle
      })
    );
  }
}
