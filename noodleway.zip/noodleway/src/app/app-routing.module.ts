import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutComponent } from './about/about.component';
import { DetailsComponent } from './details/details.component';
import { ContactComponent } from './contact/contact.component';
import { MenuComponent } from './menu/menu.component';
import { OrderOnlineComponent } from './order-online/order-online.component';
import { CartComponent } from './cart/cart.component';

const routes: Routes = [
  {path:"",component:HomePageComponent},
  {path:"about",component:AboutComponent},
  {path:"details/:slug",component:DetailsComponent},
  {path:"contact", component:ContactComponent},
  {path: "menu", component:MenuComponent},
  { path: 'cart', component: CartComponent },
  {path: "order-online", component:OrderOnlineComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
