import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  constructor(private router: Router) { }

  Products = [
    {
      title: 'Misos soup',
      images: 'https://imageproxy.wolt.com/menu/menu-images/5ba0a9f4baf84c000bb03762/2a0f81b8-429a-11ef-bb4e-2274d7c5642c_36.jpg_c_20240715150535?w=600',
      active: true,
      price: "$10",
      descr: "Miso broth, tofu, dry wakame, kama mushroom, green onion.",
      category: "Soups"
    },
    {
      title: 'Chicken soup',
      images: 'https://imageproxy.wolt.com/menu/menu-images/5ba0a9f4baf84c000bb03762/2a109dd2-429a-11ef-bb4e-2274d7c5642c_37.jpg_c_20240715150535?w=600',
      active: true,
      price: "$12",
      descr: "Egg, chicken, bulgaruli, carrot, ginger, chicken broth, atria, sesame seeds.",
      category: "Soups"
    },
    {
      title: 'Tom yam',
      images: 'https://imageproxy.wolt.com/menu/menu-images/5ba0a9f4baf84c000bb03762/2a11bd20-429a-11ef-bb4e-2274d7c5642c_2122.jpg_c_20240715150535?w=600',
      active: true,
      price: "$19",
      descr: "Tom yam broth, chicken/shrimp, wood mushroom, onion, tomato.",
      category: "Soups"
    },
    {
      title: 'Tom yum with seafood',
      images: 'https://imageproxy.wolt.com/menu/menu-images/5ba0a9f4baf84c000bb03762/2a12d6c4-429a-11ef-bb4e-2274d7c5642c_40.jpg_c_20240715150535?w=600',
      active: true,
      price: "$30",
      descr: "Tom yam broth, shrimp, squid rings, clams, clams, tomatoes, onions, wood mushrooms.",
      category: "Soups"
    },

    {
      title: 'Tom Cha',
      images: 'https://imageproxy.wolt.com/menu/menu-images/5f745dd4b6fc4593c5de43e9/1b3891a2-429a-11ef-85a7-f6055b3c5eb8_1372.jpg_c_20240715150510?w=600',
      active: true,
      price: "$20",
      descr: "Tom Ka's broth, bell pepper, tomatoes, wood mushrooms. optional (chicken, shrimps, seafood)",
      category: "Soups"
    },

    {
      title: 'Thai soup',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/a9187b7087f0d4fa22f0f74f1fab45ae3f816bb4d4cf7dafd9425dbe8cd6a682?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$11",
      descr: "Beef,Chicken,garlic,sesame seed,green pepper,green",
      category: "Soups"
    },

    {
      title: 'Glass noodles soup',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/c655558c80189512147055f8be6fa07c161aa664ff5f4251e779ee1711176eea?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$11",
      descr: "Chicken,Beef,meatballs,sesame seed,pepper,spinach,chiliflakes,garlic oil,green onion,spinach,glass noodles",
      category: "Soups"
    },

    

    {
      title: 'Main set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c87307c-429a-11ef-8e71-3e397387ac8f_83.jpg_c_20240715150510?w=600',
      active: true,
      price: "$165",
      descr: "Philadelphia Classic, Royal California, Dragon Roll, Canada Roll, Crispy Roll..",
      category: "Sets"
    },

    {
      title: 'Hot set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c88854e-429a-11ef-8e71-3e397387ac8f_82.jpg_c_20240715150510?w=600',
      active: true,
      price: "$100",
      descr: "Hot roll, fried roll, hot roll with shrimps, tempura roll.",
      category: "Sets"
    },

    {
      title: 'Vegan set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c89f28a-429a-11ef-8e71-3e397387ac8f_79.jpg_c_20240715150510?w=600',
      active: true,
      price: "$50",
      descr: "Hiashi roll, shrimp roll, avocado mac, vegetable roll.",
      category: "Sets"
    },

    {
      title: 'Salmon set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c8c7cb2-429a-11ef-8e71-3e397387ac8f_81.jpg_c_20240715150510?w=600',
      active: true,
      price: "$99",
      descr: "Philadelphia classic, California classic, roll with browned salmon, salmon mac.",
      category: "Sets"
    },

    {
      title: 'Mixed set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c8dedae-429a-11ef-8e71-3e397387ac8f_80.jpg_c_20240715150510?w=600',
      active: true,
      price: "$70",
      descr: "Roll with fried chicken, California classic, salmon mac, tuna mac.",
      category: "Sets"
    },

    {
      title: 'Premium set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c90a580-429a-11ef-8e71-3e397387ac8f_84.jpg_c_20240715150510?w=600',
      active: true,
      price: "$200",
      descr: "Hotate Roll, Royal Wasabi, Sakura Roll, Kyoto Roll, Royal Philadelphia..",
      category: "Sets"
    },

    {
      title: 'Royal set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c9201be-429a-11ef-8e71-3e397387ac8f_1029.jpg_c_20240715150510?w=600',
      active: true,
      price: "$150",
      descr: "Royal Tobiko, Royal Wasabi, Royal California, Royal Philadelphia, Wasabi, Ginger.",
      category: "Sets"
    },
    {
      title: 'Fusion set',
      images: 'https://imageproxy.wolt.com/menu/menu-images/630debba0b2146992161b4f1/1c933ed0-429a-11ef-8e71-3e397387ac8f_1030.jpg_c_20240715150510?w=600',
      active: true,
      price: "$160",
      descr: "Mango and shrimp roll, black dragon, Tokyo roll, hot roll with spicy salmon, royal tobiko, wasabi, ginger.",
      category: "Sets"
    },


    {
      title: 'Rice with seafood',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/3ed00aa070998238205dd55d0469a2148ced2faa9fcf54bc57295d64e2e67bfa?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$23",
      descr: "Mussel, shrimp, squid, octopus, Bulgarian, cabbage, carrot, sauce",
      category: "Rice"
    },
    {
      title: 'Rice with Shrimps',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/5a60fd5bf56613c947d9a6f6f1af27a746dfdb7da8b25f97aeeae994b4ec2b85?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$23",
      descr: "shrimp, Bulgarian, cabbage, carrot, sauce",
      category: "Rice"
    },

    {
      title: 'Rice with beef ',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/92f4b60c77e3afd990f356292542f1a954214c903d2d056fa65474a7030a23c2?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$18,90",
      descr: "Beef, Bulgarian, cabbage, carrot, sauce",
      category: "Rice"
    },

    {
      title: 'Rice with chicken',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/043c92b03bfd7ba4b7fd775081bd2354d5974589e64652451dbfe8142a0d08f3?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$17,90",
      descr: "Chicken meat, Bulgarian, cabbage, carrot, sauce",
      category: "Rice"
    },

    {
      title: 'California with spicy tuna',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/00bc21ce82abf3900c7d5a9ddca37b7924fa0049901e9f787b0009a0cfa0b318?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$35,90",
      descr: "Description for Rolls 1.",
      category: "Rolls"
    },
    {
      title: 'Canada roll',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/edffc359c0c5f8a7dc5a05af16461dc438fa019cc50a0dfd415d5f29875e1879?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$33,90",
      descr: "Cream cheese, avocado, eel, cucumber, sesame seeds, unagi sauce",
      category: "Rolls"
    },

    {
      title: 'Dragon roll',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/1ca7abe76397063268de8f0cbbc3f508a2f92815d569ceaa7d41bbf94dcef8ba?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$33,90",
      descr: "Cream cheese, shrimp, eel, cucumber, tobiko, unagi sauce",
      category: "Rolls"
    },

    {
      title: 'Philadelphia classic',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/5effd6c114835c4c62dd4515aba6f0543e6a43e931e5b5d83934eebe5b71634c?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$31,90",
      descr: "Cream cheese, avocado, cucumber, salmon, unagi sauce",
      category: "Rolls"
    },

    {
      title: 'Hot roll',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/5c43a443e3b47dcd184f26e459e478f4cba1c8e82c37fc1578141532572845c4?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$30",
      descr: "Cream cheese, avocado, shrimp, tempura, spicy mayonnaise, panko, thin bonito, tobiko, unagi sauce",
      category: "Rolls"
    },

    {
      title: 'Hiyas roll',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/6acf7145618bf3e85a56319220f956026aebf5f7e84a4145f71523156a7d19b9?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$24,50",
      descr: "Cucumber, avocado, shrimp, hiashi",
      category: "Rolls"
    },

    {
      title: 'Vegan roll',
      images: 'https://images.deliveryhero.io/image/menus-glovo/products/3128727c7bfdd69e2ea1d402a36230f59fb431e5362dc846a9c4731d9276de88?t=W3siYXV0byI6eyJxIjoibG93In19LHsicmVzaXplIjp7IndpZHRoIjo2MDB9fV0=',
      active: true,
      price: "$10",
      descr: "Mango sauce, avocado, cucumber, tempura, cherry tomato, lettuce, satatsu, sesame seed, green onion",
      category: "Rolls"
    },
  ];
 

  gotoOnlinePage() {
    this.router.navigate(['/order-online']);
  }
}
