import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent {

  constructor(private router: Router) { }

  gotoMenupage() {
    this.router.navigate(['/menu']);  
  }

  gotoOnlinepage() {
    this.router.navigate(['/order-online']);
  }

  submitReservationForm() {
    // Perform any necessary form submission logic here
    console.log('Form submitted!');
    // Navigate to the menu page after successful form submission
    this.router.navigate(['/menu']);
  }

}
