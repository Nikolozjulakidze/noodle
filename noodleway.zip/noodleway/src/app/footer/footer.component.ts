import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  email: string = 'contact@foodrent.com';
  phone: string = '+123456789';
  emailAddress: string = '';
  showRobotQuestion: boolean = false;
  showThanksMessage: boolean = false;

  subscribe() {
    // Show robot question after form submission
    this.showRobotQuestion = true;
  }

  cancelRobot() {
    // Handle action when user cancels and indicates they might be a robot
    console.log('User canceled indicating they might be a robot');
    // Show thanks message instead of resetting form if needed
    this.showThanksMessage = true;
    // Hide the robot question
    this.showRobotQuestion = false;
    // Optionally reset the form
    this.emailAddress = '';
  }
}
