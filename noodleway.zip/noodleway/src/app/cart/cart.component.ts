import { Component } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  submitForm(): void {
    // Handle form submission, e.g., send data to a server or display a confirmation message
    alert('Form submitted!');
  }
}
