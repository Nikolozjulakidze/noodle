import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  formData = {
    name: '',
    email: '',
    message: '',
    phoneNumber: ''
  };

  formSubmitted = false;

  constructor() { }

  submitForm() {
    console.log('Form submitted with:', this.formData);
    // Here you can add further logic, like sending the form data to a backend service
    
    // For demo purposes, simulate submission success and update formSubmitted flag
    this.formSubmitted = true;
  }
}
